### Hi, this is FancyTextGenie ✨

We build free, open-source tools for styling text with Unicode: the "fonts" you can copy and paste into Instagram bios, TikTok, Discord and game names.

- 🧰 **[Fancy-Text-Generator](https://github.com/fancytextgenie/Fancy-Text-Generator)**: a zero-dependency JavaScript library and CLI that converts text into 22 Unicode styles and back again
- 🌐 **Online tool:** https://fancytextgenie.com

𝓣𝔂𝓹𝓮 𝓸𝓷𝓬𝓮. ᴄᴏᴘʏ. 𝗣𝗮𝘀𝘁𝗲 𝗮𝗻𝘆𝘄𝗵𝗲𝗿𝗲.
