import { STYLES } from './styles.js';

const STYLE_BY_ID = new Map(STYLES.map((style) => [style.id, style]));

// Combining marks used by the strikethrough / underline styles (and by many other generators).
const COMBINING_MARKS = /[̵̶̷̸̲̳]/g;

// Reverse lookup: fancy character -> plain character.
// The first mapping wins, so caseless styles turn back into uppercase (squared)
// or lowercase (small caps) the same way they were defined.
// Upside-down text is skipped because it reuses plain letters (b <-> q, d <-> p, n <-> u).
const TO_PLAIN = new Map();
for (const style of STYLES) {
  if (!style.map || style.reverse) continue;
  for (const [plain, fancy] of Object.entries(style.map)) {
    // Skip plain ASCII output (small caps keeps "x" as "x") so normal letters are never rewritten.
    if (fancy === plain || fancy.codePointAt(0) < 0x80 || TO_PLAIN.has(fancy)) continue;
    TO_PLAIN.set(fancy, plain);
  }
}

/** Public list of styles: [{ id, name }, ...] */
export const styles = Object.freeze(STYLES.map(({ id, name }) => Object.freeze({ id, name })));

/** @returns {{ id: string, name: string }[]} */
export function listStyles() {
  return styles.slice();
}

/**
 * Convert text into one fancy style.
 *
 * @param {string} text     the text to convert
 * @param {string} styleId  one of the ids from listStyles(), e.g. "boldScript"
 * @returns {string}
 */
export function convert(text, styleId) {
  const input = String(text ?? '');
  const style = STYLE_BY_ID.get(styleId);
  if (!style) {
    const ids = STYLES.map((s) => s.id).join(', ');
    throw new TypeError(`Unknown style "${styleId}". Available styles: ${ids}`);
  }

  // Iterate by code point, not UTF-16 unit, so emoji and astral characters survive.
  const chars = Array.from(input);

  let out;
  if (style.combining) {
    out = chars.map((ch) => (ch === '\n' || ch === '\r' ? ch : ch + style.combining));
  } else {
    out = chars.map((ch) => style.map[ch] ?? ch);
  }

  if (style.reverse) out.reverse();
  return out.join('');
}

/**
 * Convert text into every style at once.
 *
 * @param {string} text
 * @returns {{ id: string, name: string, text: string }[]}
 */
export function convertAll(text) {
  return STYLES.map(({ id, name }) => ({ id, name, text: convert(text, id) }));
}

/**
 * Turn fancy text back into plain text.
 * Works for every style in this package except "upsideDown".
 * Useful for search, sorting, slugs and accessibility checks.
 *
 * @param {string} text
 * @returns {string}
 */
export function toPlain(text) {
  const input = String(text ?? '').replace(COMBINING_MARKS, '');
  return Array.from(input, (ch) => TO_PLAIN.get(ch) ?? ch).join('');
}

/**
 * Count characters the way most apps do (UTF-16 code units).
 * Many fancy letters are outside the Basic Multilingual Plane, so they count as 2.
 * Handy for checking bio limits (e.g. Instagram's 150 characters).
 *
 * @param {string} text
 * @returns {{ codePoints: number, utf16Units: number }}
 */
export function measure(text) {
  const input = String(text ?? '');
  return { codePoints: Array.from(input).length, utf16Units: input.length };
}

export default { convert, convertAll, toPlain, measure, listStyles, styles };
