// Style definitions for fancytextgenie.
//
// Most styles come from the Unicode "Mathematical Alphanumeric Symbols" block
// (U+1D400–U+1D7FF). A few letters in that block were encoded earlier in the
// "Letterlike Symbols" block (U+2100–U+214F), so those code points are reserved
// in the math block and must be mapped by hand. The `exceptions` objects below
// handle those gaps.

const A = 'A'.codePointAt(0);
const a = 'a'.codePointAt(0);
const ZERO = '0'.codePointAt(0);

const UPPER = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const LOWER = 'abcdefghijklmnopqrstuvwxyz';
const DIGITS = '0123456789';

/**
 * Build a character map from contiguous Unicode ranges.
 * @param {object} opts
 * @param {number} [opts.upper]  first code point for A
 * @param {number} [opts.lower]  first code point for a
 * @param {number} [opts.digits] first code point for 0
 * @param {object} [opts.exceptions] explicit overrides, e.g. { B: 'ℬ' }
 */
function rangeMap({ upper, lower, digits, exceptions = {} }) {
  const map = {};
  if (upper !== undefined) {
    for (const ch of UPPER) map[ch] = String.fromCodePoint(upper + ch.codePointAt(0) - A);
  }
  if (lower !== undefined) {
    for (const ch of LOWER) map[ch] = String.fromCodePoint(lower + ch.codePointAt(0) - a);
  }
  if (digits !== undefined) {
    for (const ch of DIGITS) map[ch] = String.fromCodePoint(digits + ch.codePointAt(0) - ZERO);
  }
  return Object.assign(map, exceptions);
}

/** Map both cases of every letter to one set of characters (for styles that only exist in one case). */
function caselessMap(upperStart) {
  const map = {};
  for (const ch of UPPER) {
    const out = String.fromCodePoint(upperStart + ch.codePointAt(0) - A);
    map[ch] = out;
    map[ch.toLowerCase()] = out;
  }
  return map;
}

function fromPairs(from, to) {
  const src = Array.from(from);
  const dst = Array.from(to);
  const map = {};
  src.forEach((ch, i) => {
    map[ch] = dst[i];
  });
  return map;
}

// ---------------------------------------------------------------------------
// Character maps
// ---------------------------------------------------------------------------

const smallCapsLetters = fromPairs(LOWER, 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ');
const smallCaps = { ...smallCapsLetters };
for (const ch of UPPER) smallCaps[ch] = smallCapsLetters[ch.toLowerCase()];

const upsideDownLower = fromPairs(LOWER, 'ɐqɔpǝɟƃɥᴉɾʞlɯuodbɹsʇnʌʍxʎz');
const upsideDown = {
  ...upsideDownLower,
  ...fromPairs(DIGITS, '0ƖᄅƐㄣϛ9ㄥ86'),
  '.': '˙',
  ',': "'",
  "'": ',',
  '?': '¿',
  '!': '¡',
  '(': ')',
  ')': '(',
  '[': ']',
  ']': '[',
  '{': '}',
  '}': '{',
  '<': '>',
  '>': '<',
  _: '‾',
  '&': '⅋',
};
for (const ch of UPPER) upsideDown[ch] = upsideDownLower[ch.toLowerCase()];

const fullwidth = {};
for (let cp = 0x21; cp <= 0x7e; cp += 1) {
  fullwidth[String.fromCodePoint(cp)] = String.fromCodePoint(cp + 0xfee0);
}
fullwidth[' '] = '　'; // ideographic space keeps the wide rhythm

const circled = rangeMap({
  upper: 0x24b6,
  lower: 0x24d0,
  exceptions: { 0: '⓪', ...fromPairs('123456789', '①②③④⑤⑥⑦⑧⑨') },
});

const circledNegative = {
  ...caselessMap(0x1f150),
  0: '⓿',
  ...fromPairs('123456789', '❶❷❸❹❺❻❼❽❾'),
};

// ---------------------------------------------------------------------------
// Style list
// ---------------------------------------------------------------------------

/**
 * Every style has:
 *   id          – the key you pass to convert()
 *   name        – human-readable name
 *   map         – character map (characters not in the map are kept as they are)
 *   combining   – (optional) a combining mark added after every character instead of a map
 *   reverse     – (optional) reverse the result (used by upside-down text)
 */
export const STYLES = [
  {
    id: 'bold',
    name: 'Bold (serif)',
    map: rangeMap({ upper: 0x1d400, lower: 0x1d41a, digits: 0x1d7ce }),
  },
  {
    id: 'italic',
    name: 'Italic (serif)',
    map: rangeMap({ upper: 0x1d434, lower: 0x1d44e, exceptions: { h: 'ℎ' } }),
  },
  {
    id: 'boldItalic',
    name: 'Bold italic (serif)',
    map: rangeMap({ upper: 0x1d468, lower: 0x1d482 }),
  },
  {
    id: 'script',
    name: 'Script / cursive',
    map: rangeMap({
      upper: 0x1d49c,
      lower: 0x1d4b6,
      exceptions: {
        B: 'ℬ', E: 'ℰ', F: 'ℱ', H: 'ℋ', I: 'ℐ', L: 'ℒ', M: 'ℳ', R: 'ℛ',
        e: 'ℯ', g: 'ℊ', o: 'ℴ',
      },
    }),
  },
  {
    id: 'boldScript',
    name: 'Bold script / cursive',
    map: rangeMap({ upper: 0x1d4d0, lower: 0x1d4ea }),
  },
  {
    id: 'fraktur',
    name: 'Gothic (Fraktur)',
    map: rangeMap({
      upper: 0x1d504,
      lower: 0x1d51e,
      exceptions: { C: 'ℭ', H: 'ℌ', I: 'ℑ', R: 'ℜ', Z: 'ℨ' },
    }),
  },
  {
    id: 'boldFraktur',
    name: 'Bold gothic (Fraktur)',
    map: rangeMap({ upper: 0x1d56c, lower: 0x1d586 }),
  },
  {
    id: 'doubleStruck',
    name: 'Double-struck / outline',
    map: rangeMap({
      upper: 0x1d538,
      lower: 0x1d552,
      digits: 0x1d7d8,
      exceptions: { C: 'ℂ', H: 'ℍ', N: 'ℕ', P: 'ℙ', Q: 'ℚ', R: 'ℝ', Z: 'ℤ' },
    }),
  },
  {
    id: 'sans',
    name: 'Sans-serif',
    map: rangeMap({ upper: 0x1d5a0, lower: 0x1d5ba, digits: 0x1d7e2 }),
  },
  {
    id: 'sansBold',
    name: 'Sans-serif bold',
    map: rangeMap({ upper: 0x1d5d4, lower: 0x1d5ee, digits: 0x1d7ec }),
  },
  {
    id: 'sansItalic',
    name: 'Sans-serif italic',
    map: rangeMap({ upper: 0x1d608, lower: 0x1d622 }),
  },
  {
    id: 'sansBoldItalic',
    name: 'Sans-serif bold italic',
    map: rangeMap({ upper: 0x1d63c, lower: 0x1d656 }),
  },
  {
    id: 'monospace',
    name: 'Monospace / typewriter',
    map: rangeMap({ upper: 0x1d670, lower: 0x1d68a, digits: 0x1d7f6 }),
  },
  {
    id: 'fullwidth',
    name: 'Fullwidth / vaporwave',
    map: fullwidth,
  },
  {
    id: 'smallCaps',
    name: 'Small caps',
    map: smallCaps,
  },
  {
    id: 'circled',
    name: 'Bubble (circled)',
    map: circled,
  },
  {
    id: 'circledNegative',
    name: 'Bubble filled (negative circled)',
    map: circledNegative,
  },
  {
    id: 'squared',
    name: 'Squared',
    map: caselessMap(0x1f130),
  },
  {
    id: 'squaredNegative',
    name: 'Squared filled (negative squared)',
    map: caselessMap(0x1f170),
  },
  {
    id: 'upsideDown',
    name: 'Upside down',
    map: upsideDown,
    reverse: true,
  },
  {
    id: 'strikethrough',
    name: 'Strikethrough',
    combining: '̶',
  },
  {
    id: 'underline',
    name: 'Underline',
    combining: '̲',
  },
];
