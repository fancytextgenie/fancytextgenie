export type StyleId =
  | 'bold'
  | 'italic'
  | 'boldItalic'
  | 'script'
  | 'boldScript'
  | 'fraktur'
  | 'boldFraktur'
  | 'doubleStruck'
  | 'sans'
  | 'sansBold'
  | 'sansItalic'
  | 'sansBoldItalic'
  | 'monospace'
  | 'fullwidth'
  | 'smallCaps'
  | 'circled'
  | 'circledNegative'
  | 'squared'
  | 'squaredNegative'
  | 'upsideDown'
  | 'strikethrough'
  | 'underline';

export interface StyleInfo {
  readonly id: StyleId;
  readonly name: string;
}

export interface ConvertedText {
  id: StyleId;
  name: string;
  text: string;
}

export declare const styles: readonly StyleInfo[];
export declare function listStyles(): StyleInfo[];
export declare function convert(text: string, styleId: StyleId): string;
export declare function convertAll(text: string): ConvertedText[];
export declare function toPlain(text: string): string;
export declare function measure(text: string): { codePoints: number; utf16Units: number };

declare const _default: {
  convert: typeof convert;
  convertAll: typeof convertAll;
  toPlain: typeof toPlain;
  measure: typeof measure;
  listStyles: typeof listStyles;
  styles: typeof styles;
};
export default _default;
