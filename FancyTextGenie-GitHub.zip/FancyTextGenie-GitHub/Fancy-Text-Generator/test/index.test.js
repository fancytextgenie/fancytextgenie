import { test } from 'node:test';
import assert from 'node:assert/strict';
import { convert, convertAll, toPlain, measure, listStyles, styles } from '../src/index.js';

const SAMPLE = 'The quick brown fox jumps over the lazy dog 0123456789';

test('lists 22 styles with unique ids', () => {
  const ids = listStyles().map((s) => s.id);
  assert.equal(ids.length, 22);
  assert.equal(new Set(ids).size, ids.length);
  assert.equal(styles.length, 22);
});

test('converts to the expected characters', () => {
  assert.equal(convert('Hello', 'bold'), '𝐇𝐞𝐥𝐥𝐨');
  assert.equal(convert('Hello', 'boldScript'), '𝓗𝓮𝓵𝓵𝓸');
  assert.equal(convert('Hello', 'fraktur'), 'ℌ𝔢𝔩𝔩𝔬');
  assert.equal(convert('Hello', 'circled'), 'Ⓗⓔⓛⓛⓞ');
  assert.equal(convert('Hello', 'smallCaps'), 'ʜᴇʟʟᴏ');
  assert.equal(convert('vibes', 'fullwidth'), 'ｖｉｂｅｓ');
  assert.equal(convert('hey', 'upsideDown'), 'ʎǝɥ');
  assert.equal(convert('ab', 'strikethrough'), 'a̶b̶');
});

test('uses the Letterlike Symbols block for reserved math code points', () => {
  assert.equal(convert('BEFHILMR', 'script'), 'ℬℰℱℋℐℒℳℛ');
  assert.equal(convert('ego', 'script'), 'ℯℊℴ');
  assert.equal(convert('h', 'italic'), 'ℎ');
  assert.equal(convert('CHIRZ', 'fraktur'), 'ℭℌℑℜℨ');
  assert.equal(convert('CHNPQRZ', 'doubleStruck'), 'ℂℍℕℙℚℝℤ');
});

test('keeps characters that a style does not cover', () => {
  assert.equal(convert('Hi! 🎉', 'bold'), '𝐇𝐢! 🎉');
  assert.equal(convert('café', 'monospace'), '𝚌𝚊𝚏é');
});

test('throws a helpful error for an unknown style', () => {
  assert.throws(() => convert('x', 'comicSans'), /Unknown style "comicSans"/);
});

test('convertAll returns one result per style', () => {
  const all = convertAll('Hi');
  assert.equal(all.length, 22);
  assert.ok(all.every((r) => typeof r.text === 'string' && r.text.length > 0));
});

test('toPlain reverses every style except upside down', () => {
  for (const { id } of listStyles()) {
    if (id === 'upsideDown') continue;
    const fancy = convert(SAMPLE, id);
    const plain = toPlain(fancy);
    if (['smallCaps'].includes(id)) {
      assert.equal(plain, SAMPLE.toLowerCase(), id);
    } else if (['squared', 'squaredNegative', 'circledNegative'].includes(id)) {
      assert.equal(plain, SAMPLE.toUpperCase(), id);
    } else {
      assert.equal(plain, SAMPLE, id);
    }
  }
});

test('measure shows why fancy text fills bio limits faster', () => {
  assert.deepEqual(measure('Hi'), { codePoints: 2, utf16Units: 2 });
  assert.deepEqual(measure(convert('Hi', 'bold')), { codePoints: 2, utf16Units: 4 });
});
